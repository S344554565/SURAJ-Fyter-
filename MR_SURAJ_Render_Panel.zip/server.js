const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.disable("x-powered-by");
app.use(express.static(path.join(__dirname, "public")));

app.get("/health", (_req, res) => {
  res.json({ ok: true, owner: "MR SURAJ" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`MR SURAJ panel listening on port ${PORT}`);
});
